@echo off
.\python.exe NewTool.py
pause

import os
import ctypes  # <--- 必须导入这个，否则弹窗会报错
from openpyxl import Workbook
from openpyxl.styles import Font

# 1. 这一段是“说明书”
def create_excel_with_sheets(folder_dict, output_path):
    wb = Workbook()
    if 'Sheet' in wb.sheetnames:
        wb.remove(wb['Sheet'])
    
    for sheet_name, folder_path in folder_dict.items():
        # Excel 工作表名称不能超过 31 个字符，且不能包含特殊字符 : \ / ? * [ ]
        safe_name = sheet_name[:30].replace("[", "").replace("]", "")
        ws = wb.create_sheet(title=safe_name)
        
        try:
            files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
            ws.append(["文件名称", "文件链接"])
            
            for file_name in files:
                file_path = os.path.join(folder_path, file_name)
                # 第一列：文件名
                ws.cell(row=ws.max_row + 1, column=1, value=file_name)
                # 第二列：超链接
                link_cell = ws.cell(row=ws.max_row, column=2, value="点击打开文件")
                link_cell.hyperlink = file_path
                link_cell.font = Font(color="0000FF", underline="single")
        except Exception as e:
            ws.append(["错误", f"无法读取文件夹: {e}"])
            
    wb.save(output_path)

# 2. 这里的“总开关”
if __name__ == "__main__":
    # 获取当前脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    folders = {}
    
    # 过滤掉 Python 相关的包文件夹，避免把库文件也扫进报表
    exclude_list = ["openpyxl", "et_xmlfile", "__pycache__", "python", "venv", ".git"]
    
    print("🚀 正在扫描文件夹，准备生成索引报表...")
    
    folder_count = 0
    for item in os.listdir(script_dir):
        item_path = os.path.join(script_dir, item)
        # 只记录文件夹，且不在排除名单内
        if os.path.isdir(item_path) and item not in exclude_list:
            folders[item] = item_path
            folder_count += 1
            
    if not folders:
        print("❌ 未发现可扫描的邮件文件夹。请检查脚本是否放对了地方。")
    else:
        output_name = "邮件归档索引表.xlsx"
        output_excel = os.path.join(script_dir, output_name) 
        
        try:
            create_excel_with_sheets(folders, output_excel)
            
            # 3. 调用 Windows 系统弹窗
            msg_content = f"Hi 主人！\n\n扫描完毕！已为 {folder_count} 个文件夹建立索引。\n是否立刻打开 Excel 报表？"
            msg_title = "MailIndex 自动化助手"
            
            # res 为 1 代表用户点击了“确定”
            res = ctypes.windll.user32.MessageBoxW(0, msg_content, msg_title, 1)
            
            if res == 1:
                print("📅 遵命！正在为您打开 Excel...")
                os.startfile(output_excel) 
            else:
                print("☕ 收到！文件已保存在脚本同级目录下。")
        except PermissionError:
            print("❌ 错误：Excel 文件正被占用，请先关闭旧的 Excel 文件后再运行！")
        except Exception as e:
            print(f"❌ 运行过程中出现意外：{e}")

    print("\n✅ 程序运行结束。")
